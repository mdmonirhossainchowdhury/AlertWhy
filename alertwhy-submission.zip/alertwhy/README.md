# AlertWhy - an AML alert investigator that explains *why*

**Open Agent Hackathon 2026 - Track 02: The Agent That Can Explain Why**

Banks drown in transaction-monitoring alerts, and most are false positives. For each one, an analyst opens five
systems (core banking, KYC, sanctions lists, news, reference data), pieces together the story, and must write down
*why* - regulators require an auditable reason. AlertWhy automates that investigation:

1. **Plans** the investigation and **queries fragmented sources in place** (no data copied into a central store).
2. **Connects the findings** into a numbered evidence chain - risk factors *and* mitigating evidence.
3. Returns a **verdict** (ESCALATE / CLOSE / REVIEW), a risk score, a confidence, and a cited explanation.
4. Keeps a full **audit trail** (every SQL query) and **meters the cost** of each investigation.

Live Zetaris + Nightshift setup (required before you submit): see `docs/LOCAL_SETUP.md`.

## Quick start (about 2 minutes)

```bash
unzip alertwhy.zip && cd alertwhy
./run.sh            # Windows: run.bat   | or: docker build -t alertwhy . && docker run -p 8000:8000 alertwhy
# open http://localhost:8000
```

Requires Python 3.10+. First start generates the synthetic bank in `data/`. No API keys needed for the demo.

```bash
python -m alertwhy.cli eval          # run all 19 alerts and compare with hidden planted labels
python -m alertwhy.cli investigate A-1002
python -m pytest -q                  # 114 tests
```

## How it works

```
                       +--------------------- AlertWhy agent ----------------------+
 Analyst UI / API ---> | plan -> 10 investigation tools -> evidence chain -> verdict |
 (FastAPI + HTML)      |                    |                          |            |
                       |                    v                          v            |
                       |        Federation.query(sql)         optional LLM narrator |
                       |                    |                 (citation-guarded)    |
                       +--------------------|-------------------------|-------------+
                                            v                         v
                   Zetaris (query-in-place)                   Meterless usage event
          core_banking.duckdb | kyc.parquet | sanctions.csv      (queries, rows, tokens, $)
                   adverse_media.jsonl | jurisdictions.csv
```

Design choices judges may care about:

- **Evidence engine decides, LLM only explains.** Score and verdict come from transparent rules over queried facts.
  An optional LLM writes the narrative; a *citation guard* rejects any text citing evidence IDs that do not exist,
  falling back to a deterministic template. The agent therefore cannot invent facts.
- **Mitigating evidence matters.** Same-name sanctions hits with different DOB/country, payroll batches and
  long-standing customer patterns *lower* risk, so false positives get closed with a cited reason.
- **Honest uncertainty.** A serious red flag blocks auto-closure; mixed signals route to REVIEW; hard rule: any strong
  sanctions match always escalates. Decision support only - a human confirms.
- **Cost-aware.** Every investigation emits a usage event and respects a per-investigation budget
  (`MAX_COST_PER_INVESTIGATION_USD`); over budget, the LLM step is skipped.

## Sponsor integrations - exact status

| Sponsor | What is built | What you must do |
|---|---|---|
| **Zetaris** | All data access goes through `Federation.query()` (`alertwhy/federation.py`). The offline demo uses DuckDB; the Zetaris adapter is covered by contract fakes. A live Zetaris connection has not been verified in this environment. | Configure `ZETARIS_REST_URL`, `ZETARIS_ORG_ID`, and `ZETARIS_API_KEY` in `.env`, then register and verify the sample tables as described below. |
| **Meterless** | Nightshift is supported as the primary OpenAI-compatible AI provider. H-MEM (Apache-2.0, vendored in `engines/hmem`) supplies analyst memory. Nightshift has not been live-connected in this environment. | Configure `METERLESS_BASE_URL` and `METERLESS_RUNTIME_TOKEN` from the Nightshift Console in `.env`. |
| **NVIDIA Nemotron** (optional) | An optional secondary OpenAI-compatible provider is supported. | Configure `MODEL_BASE_URL`, `MODEL_API_KEY`, and `NEMOTRON_MODEL` if using Nemotron. |
| **Cursor** (required) | Project rules are in `.cursor/rules/`. | Record your real Cursor sessions in `docs/CURSOR_LOG.md`. |

### Connect the live integrations

1. Copy `.env.example` to `.env`. Keep `.env` private and do not paste credentials into chat.
2. For the sample Zetaris data, install/start Docker and Zetaris using the participant setup guide. Set
   `ALERTWHY_PG_PASSWORD` in `.env`, then run `python -m alertwhy.cli export-pg` and `docker compose up -d postgres`.
3. In the Zetaris web UI, create your API key. Set `ZETARIS_REST_URL` to the REST URL shown by your installation,
   and set `ZETARIS_API_KEY` in `.env`. `ZETARIS_ORG_ID` defaults to `1` for a local install.
4. Run `python scripts/zetaris_setup.py` to preview datasource registration. To apply it, run
   `python scripts/zetaris_setup.py --apply` (or the alias `python scripts/zetaris_setup.py all`).
5. Start Nightshift using the participant setup guide. Copy its Runtime URL and token from the Nightshift Console
   into `METERLESS_BASE_URL` and `METERLESS_RUNTIME_TOKEN`.
6. Restart AlertWhy and run `python -m alertwhy.cli status`. The command succeeds only when Zetaris, Nightshift,
   and the H-MEM engine are online. The local DuckDB fallback is not a live Zetaris connection.

The usage ledger (`alertwhy/usage.py`) records local estimates; it is not Meterless billing data. Do not claim live
sponsor connectivity in a demo unless the status check confirms it.

## Data

Everything is **synthetic**: 289 customers, ~14,000 transactions, and 19 alerts across 5 sources in 4 formats.
Names are fictional; the country risk tiers are illustrative, **not an official list** (replace with FATF data
for real use). Nine planted scenarios: structuring, true sanctions hit, same-name false positive, layering through a
new entity, adverse media, established-customer large wire, dormant-account reactivation, payroll batch,
ambiguous new customer - plus 10 routine cash alerts.

**About the 100% result:** `ground_truth.csv` labels were written by us alongside the data and rules, so
19/19 shows the pipeline works end to end - it is **not** a measure of real-world accuracy. Evaluate on real, labelled
alert data before any production claim.

## Project layout

```
alertwhy/ config.py datagen.py federation.py sqlguard.py tools.py agent.py brain.py llm.py hmem.py usage.py pgexport.py api.py cli.py
static/index.html     single-file analyst UI (no build step)
tests/                  114 tests (Zetaris contract via fakes, SQL guard, Nightshift provider, H-MEM conformance and memory, agent loop, API, UI copy)
docs/                 ARCHITECTURE.md  DEMO_SCRIPT.md  SLIDES.md  CURSOR_LOG.md  SUBMISSION_CHECKLIST.md
```

## Troubleshooting

- `Could not set lock on file ... core_banking.duckdb`: another AlertWhy instance is still running and holds the
  database. Stop it (or use `PORT=8001 ./run.sh` only after stopping the first one) - run a single server per `data/` folder.
- Want fresh data/ledger? Delete the `data/` folder; it is regenerated on next start.

## Extending

- Add a rule: write a function returning `ev(...)` items in `tools.py` and append it to `TOOLS`.
- Add a source: expose it as a Zetaris virtual table / DuckDB view and query it through `ctx.q(...)`.
- Tune thresholds with `ESCALATE_AT` / `CLOSE_AT`.

## License

MIT for the hackathon submission code. Synthetic data only.


## Sponsor technology
See [docs/SPONSOR_TECH.md](docs/SPONSOR_TECH.md) for how Zetaris and Meterless are used and why.
